I used Ubuntu 17.10

Please run using hw3tester.txt
