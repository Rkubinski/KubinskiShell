int parseinput(char comm[]);
void shell();
