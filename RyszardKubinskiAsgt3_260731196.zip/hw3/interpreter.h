
int interpreter(char *command[], int argcount);
