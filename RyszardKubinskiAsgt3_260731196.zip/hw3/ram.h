#include <stdio.h>





void removeFILEPT(FILE *f);

int findTop();



