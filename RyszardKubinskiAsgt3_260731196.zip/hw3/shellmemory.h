int print(char *k);
int insert (char *k, char *v);
