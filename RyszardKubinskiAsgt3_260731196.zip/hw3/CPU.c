#include <stdio.h>



struct CPU 
	{FILE *IP; char IR[1000]; int quanta=2;}
